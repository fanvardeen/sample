import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CategoryService } from './category.service';
import { Router } from '@angular/router';
import { ILogin } from './ILogin';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  login: ILogin;
  loginForm: FormGroup;

  constructor(private _categoryService: CategoryService, private fb: FormBuilder, private router: Router) { }

  ngOnInit(): void {
    this.loginForm = this.fb.group({
      countryId: ['3676893a-5d5b-427e-a54b-cce5c2633a3b'],
      username: ['', [Validators.required]],
      password: ['', [Validators.required]],
      expiresInMinute: [20]
    });

    // let observable = this._categoryService.getCountry();
    // observable.subscribe((data: ICountry[]) => {
    //   this.country = data;
    //   console.log(this.country);

    // });

    // this.loginForm = this.fb.group({
    //   countryId: ['3676893a-5d5b-427e-a54b-cce5c2633a3b'],
    //   username: ['5551122'],
    //   password: ['123456789'],
    //   expiresInMinute: [20]
    // });

  }

  onSubmit(): void {
    console.log(this.loginForm.value);
    this.login = <ILogin>this.loginForm.value;

    this._categoryService.addLogin(this.login).subscribe(
      () => this.router.navigate(['home']),
      (err: any) => console.log(err)
    );
  }
}


