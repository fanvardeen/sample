export interface ICountry {
    id: string;
    name: string,
    phoneCode: string,
    countryCode: string
}
