import { ISubCategories } from './ISubCategories';

export interface ICategory {
    id: string;
    title: string;
    subCategories: ISubCategories[];
}
