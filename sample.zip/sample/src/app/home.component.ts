import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder } from '@angular/forms';
import { CategoryService } from './category.service';
import { ICategory } from './ICategory';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  //categoryForm: FormGroup;

  category: ICategory[];

  constructor(private _categoryService: CategoryService) { }



  ngOnInit(): void {

    // this.categoryForm = this.fb.group({
    //   id: [''],
    //   title: [''],
    //   subCategories: this.fb.array([
    //     this.addSubFormGroup()
    //   ])
    // });

    // this._categoryService.getCategory().subscribe(
    //   (categoryList) => this.category = categoryList.findIndex[0],
    //   (err) => console.log(err)
    // );

    let observable = this._categoryService.getCategory();
    observable.subscribe((data: ICategory[]) => {
      this.category = data;


      console.log(this.category);
    });


    //this._categoryService.getCategory().subscribe((data: ICategory[]) => this.category = data);

  }



  // addSubFormGroup(): FormGroup {
  //   return this.fb.group({
  //     id: [''],
  //     title: ['']
  //   });
  // }

}
